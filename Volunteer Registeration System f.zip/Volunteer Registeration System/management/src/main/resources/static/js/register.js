document.addEventListener("DOMContentLoaded", () => {

    const registerForm = document.getElementById("registerForm");
    const message      = document.getElementById("message");

    registerForm.addEventListener("submit", async (e) => {

        e.preventDefault();

        // ── Read values ──────────────────────────────────────
        const firstName = document.getElementById("firstName").value.trim();
        const lastName  = document.getElementById("lastName").value.trim();
        const email     = document.getElementById("email").value.trim();
        const password  = document.getElementById("password").value;
        const role      = document.getElementById("role").value;

        // ── Frontend validation ──────────────────────────────
        if (!firstName || !lastName || !email || !password) {
            message.style.color = "#ef4444";
            message.innerText   = "All fields are required.";
            return;
        }

        if (firstName.length < 2 || firstName.length > 50) {
            message.style.color = "#ef4444";
            message.innerText   = "First name must be 2–50 characters.";
            return;
        }

        if (lastName.length < 2 || lastName.length > 50) {
            message.style.color = "#ef4444";
            message.innerText   = "Last name must be 2–50 characters.";
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            message.style.color = "#ef4444";
            message.innerText   = "Please enter a valid email address.";
            return;
        }

        if (password.length < 8) {
            message.style.color = "#ef4444";
            message.innerText   = "Password must be at least 8 characters.";
            return;
        }

        // ── Must match backend @Pattern exactly ──────────────
        const hasUppercase = /[A-Z]/.test(password);
        const hasNumber    = /[0-9]/.test(password);
        const hasSpecial   = /[@#$%^&+=!]/.test(password);

        if (!hasUppercase) {
            message.style.color = "#ef4444";
            message.innerText   = "Password must contain at least one uppercase letter (A-Z).";
            return;
        }

        if (!hasNumber) {
            message.style.color = "#ef4444";
            message.innerText   = "Password must contain at least one number (0-9).";
            return;
        }

        if (!hasSpecial) {
            message.style.color = "#ef4444";
            message.innerText   = "Password must contain at least one special character: @ # $ % ^ & + = !";
            return;
        }

        // ── Show loading state ────────────────────────────────
        message.style.color = "#94a3b8";
        message.innerText   = "Creating your account...";

        // ── Build request body ────────────────────────────────
        const registerData = {
            firstName : firstName,
            lastName  : lastName,
            email     : email,
            password  : password,
            role      : role
        };

        // ── Call backend ──────────────────────────────────────
        try {

            const response = await fetch("/api/auth/register", {
                method  : "POST",
                headers : { "Content-Type": "application/json" },
                body    : JSON.stringify(registerData)
            });

            const result = await response.json();

            if (response.ok && result.success) {

                // ── Success ───────────────────────────────────
                message.style.color = "#22c55e";
                message.innerText   = "Account created successfully! Redirecting to login...";

                setTimeout(() => {
                    window.location.href = "/login.html";
                }, 1500);

            } else {

                // ── Backend validation errors ─────────────────
                if (result.validationErrors) {

                    const errors = Object.entries(result.validationErrors)
                        .map(([field, msg]) => `${field}: ${msg}`)
                        .join(" | ");

                    message.style.color = "#ef4444";
                    message.innerText   = errors;

                } else {

                    message.style.color = "#ef4444";
                    message.innerText   = result.message || "Registration failed. Please try again.";
                }
            }

        } catch (error) {

            console.error("Register error:", error);
            message.style.color = "#ef4444";
            message.innerText   = "Cannot connect to server. Make sure backend is running on port 8080.";
        }

    });

});