document.addEventListener("DOMContentLoaded", () => {

    const BASE_URL = "http://localhost:8080";
    const token    = localStorage.getItem("accessToken");

    // ── Auth Guard ────────────────────────────────────────────
    if (!token) {
        window.location.href = "/login.html";
        return;
    }

    // ── Show admin name ───────────────────────────────────────
    const adminName = document.getElementById("adminName");
    if (adminName) {
        adminName.textContent = localStorage.getItem("userName") || "Admin";
    }

    // ── Logout ────────────────────────────────────────────────
    window.logout = function () {
        localStorage.clear();
        window.location.href = "/login.html";
    };

    // ── Shared fetch helper ───────────────────────────────────
    async function apiFetch(endpoint) {
        const res = await fetch(`${BASE_URL}${endpoint}`, {
            method : "GET",
            headers: {
                "Content-Type" : "application/json",
                "Authorization": `Bearer ${token}`
            }
        });

        if (res.status === 401 || res.status === 403) {
            localStorage.clear();
            window.location.href = "/login.html";
            return null;
        }

        const result = await res.json();
        return result.data;
    }

    // =========================================================
    // 1. DASHBOARD STATS
    // =========================================================
    async function loadDashboard() {
        try {
            const data = await apiFetch("/api/dashboard");
            if (!data) return;

            setEl("totalVolunteers",    data.totalVolunteers);
            setEl("totalUsers",         data.totalUsers);
            setEl("totalEvents",        data.totalEvents);
            setEl("activeEvents",       data.activeEvents);
            setEl("totalApplications",  data.totalApplications);
            setEl("pendingApplications",data.pendingApplications);
            setEl("approvedApplications",data.approvedApplications);
            setEl("rejectedApplications",data.rejectedApplications);
            setEl("attendanceRecords",  data.totalAttendanceRecords);
            setEl("presentCount",       data.presentCount);

        } catch (err) {
            console.error("Dashboard error:", err);
        }
    }

    // =========================================================
    // 2. VOLUNTEERS TABLE
    // =========================================================
    async function loadVolunteers() {
        const tbody = document.getElementById("volunteersTableBody");
        if (!tbody) return;

        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:1rem;color:#94a3b8;">Loading...</td></tr>`;

        try {
            const data = await apiFetch(
                "/api/volunteers?page=0&size=10&sortBy=volunteerId&sortDir=desc"
            );
            if (!data) return;

            // ✅ Your API returns PagedResponse — data is in data.content
            const volunteers = data.content || [];

            if (volunteers.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:1rem;color:#94a3b8;">No volunteers found.</td></tr>`;
                return;
            }

            tbody.innerHTML = "";
            volunteers.forEach(v => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${v.volunteerId}</td>
                    <td>${v.firstName} ${v.lastName}</td>
                    <td>${v.email}</td>
                    <td>${v.skills || "—"}</td>
                    <td>${v.availability || "—"}</td>
                `;
                tbody.appendChild(tr);
            });

        } catch (err) {
            console.error("Volunteers error:", err);
            tbody.innerHTML = `<tr><td colspan="5" style="color:red;padding:1rem;">Failed to load volunteers.</td></tr>`;
        }
    }

    // =========================================================
    // 3. EVENTS TABLE
    // =========================================================
    async function loadEvents() {
        const tbody = document.getElementById("eventsTableBody");
        if (!tbody) return;

        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:1rem;color:#94a3b8;">Loading...</td></tr>`;

        try {
            const data = await apiFetch(
                "/api/events?page=0&size=10&sortBy=eventId&sortDir=desc"
            );
            if (!data) return;

            // ✅ data.content from PagedResponse
            const events = data.content || [];

            if (events.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:1rem;color:#94a3b8;">No events found.</td></tr>`;
                return;
            }

            tbody.innerHTML = "";
            events.forEach(e => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${e.eventName}</td>
                    <td>${e.location}</td>
                    <td>${e.eventDate}</td>
                    <td>${e.requiredVolunteers}</td>
                    <td>${e.approvedVolunteersCount}</td>
                `;
                tbody.appendChild(tr);
            });

        } catch (err) {
            console.error("Events error:", err);
            tbody.innerHTML = `<tr><td colspan="5" style="color:red;padding:1rem;">Failed to load events.</td></tr>`;
        }
    }

    // =========================================================
    // 4. ATTENDANCE TABLE
    // =========================================================
    async function loadAttendance() {
        const tbody = document.getElementById("attendanceTableBody");
        if (!tbody) return;

        tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;padding:1rem;color:#94a3b8;">Loading...</td></tr>`;

        try {
            const data = await apiFetch(
                "/api/attendance?page=0&size=10&sortBy=attendanceId&sortDir=desc"
            );
            if (!data) return;

            // ✅ data.content from PagedResponse
            const records = data.content || [];

            if (records.length === 0) {
                tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;padding:1rem;color:#94a3b8;">No attendance records found.</td></tr>`;
                return;
            }

            tbody.innerHTML = "";
            records.forEach(a => {
                const tr = document.createElement("tr");
                const statusColor = a.present ? "#22c55e" : "#ef4444";
                const statusText  = a.present ? "Present" : "Absent";
                tr.innerHTML = `
                    <td>${a.attendanceId}</td>
                    <td>${a.volunteerName}</td>
                    <td>${a.eventName}</td>
                    <td><span style="color:${statusColor};font-weight:600;">${statusText}</span></td>
                `;
                tbody.appendChild(tr);
            });

        } catch (err) {
            console.error("Attendance error:", err);
            tbody.innerHTML = `<tr><td colspan="4" style="color:red;padding:1rem;">Failed to load attendance.</td></tr>`;
        }
    }

    // =========================================================
    // 5. REPORT DOWNLOADS
    // =========================================================
    window.downloadVolunteerReport = async function () {
        downloadReport("/api/reports/volunteers", "volunteer_report.xlsx");
    };

    window.downloadEventReport = async function () {
        downloadReport("/api/reports/events", "event_report.xlsx");
    };

    window.downloadAttendanceReport = async function () {
        downloadReport("/api/reports/attendance", "attendance_report.xlsx");
    };

    async function downloadReport(endpoint, filename) {
        try {
            const res = await fetch(`${BASE_URL}${endpoint}`, {
                method : "GET",
                headers: { "Authorization": `Bearer ${token}` }
            });

            if (!res.ok) {
                alert("Failed to download report. Make sure you have ADMIN access.");
                return;
            }

            // ✅ Convert blob to downloadable file
            const blob = await res.blob();
            const url  = window.URL.createObjectURL(blob);
            const a    = document.createElement("a");
            a.href     = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);

        } catch (err) {
            console.error("Download error:", err);
            alert("Download failed. Check console for details.");
        }
    }

    // =========================================================
    // Helper
    // =========================================================
    function setEl(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value ?? "0";
    }

    // =========================================================
    // INIT — load everything
    // =========================================================
    loadDashboard();
    loadVolunteers();
    loadEvents();
    loadAttendance();

    // =========================================================
// MODAL OPEN / CLOSE
// =========================================================
    window.openModal = function(modalId) {
        const overlay = document.getElementById("modalOverlay");
        const modal   = document.getElementById(modalId);
        if (!overlay || !modal) return;

        // Hide all modals first
        document.querySelectorAll(".modal-box").forEach(m => {
            m.style.display = "none";
        });

        overlay.style.display  = "flex";
        modal.style.display    = "block";
    };

    window.closeModal = function() {
        const overlay = document.getElementById("modalOverlay");
        if (overlay) overlay.style.display = "none";

        document.querySelectorAll(".modal-box").forEach(m => {
            m.style.display = "none";
        });
    };

// Close modal when clicking overlay background
    document.getElementById("modalOverlay")?.addEventListener("click", function(e) {
        if (e.target === this) closeModal();
    });

// =========================================================
// ADD VOLUNTEER
// =========================================================
    document.getElementById("addVolunteerForm")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const msg = document.getElementById("volMsg");
        msg.style.color = "#94a3b8";
        msg.textContent = "Saving...";

        const body = {
            firstName      : document.getElementById("vol_firstName").value.trim(),
            lastName       : document.getElementById("vol_lastName").value.trim(),
            email          : document.getElementById("vol_email").value.trim(),
            phone          : document.getElementById("vol_phone").value.trim(),
            age            : parseInt(document.getElementById("vol_age").value),
            gender         : document.getElementById("vol_gender").value,
            address        : document.getElementById("vol_address").value.trim(),
            skills         : document.getElementById("vol_skills").value.trim(),
            availability   : document.getElementById("vol_availability").value,
            emergencyContact: document.getElementById("vol_emergency").value.trim()
        };

        try {
            const res = await fetch(`${BASE_URL}/api/volunteers`, {
                method : "POST",
                headers: {
                    "Content-Type" : "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(body)
            });

            const result = await res.json();

            if (res.ok && result.success) {
                msg.style.color = "#22c55e";
                msg.textContent = "Volunteer added successfully!";
                setTimeout(() => {
                    closeModal();
                    loadVolunteers(); // refresh table
                }, 1200);
            } else {
                msg.style.color = "#ef4444";
                if (result.validationErrors) {
                    msg.textContent = Object.values(result.validationErrors).join(" | ");
                } else {
                    msg.textContent = result.message || "Failed to add volunteer.";
                }
            }
        } catch (err) {
            msg.style.color = "#ef4444";
            msg.textContent = "Server error. Try again.";
        }
    });

// =========================================================
// ADD EVENT
// =========================================================
    document.getElementById("addEventForm")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const msg = document.getElementById("evtMsg");
        msg.style.color = "#94a3b8";
        msg.textContent = "Saving...";

        const body = {
            eventName         : document.getElementById("evt_name").value.trim(),
            description       : document.getElementById("evt_desc").value.trim(),
            location          : document.getElementById("evt_location").value.trim(),
            eventDate         : document.getElementById("evt_date").value,
            requiredVolunteers: parseInt(document.getElementById("evt_required").value),
            organizer         : document.getElementById("evt_organizer").value.trim()
        };

        try {
            const res = await fetch(`${BASE_URL}/api/events`, {
                method : "POST",
                headers: {
                    "Content-Type" : "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(body)
            });

            const result = await res.json();

            if (res.ok && result.success) {
                msg.style.color = "#22c55e";
                msg.textContent = "Event created successfully!";
                setTimeout(() => {
                    closeModal();
                    loadEvents(); // refresh table
                }, 1200);
            } else {
                msg.style.color = "#ef4444";
                if (result.validationErrors) {
                    msg.textContent = Object.values(result.validationErrors).join(" | ");
                } else {
                    msg.textContent = result.message || "Failed to create event.";
                }
            }
        } catch (err) {
            msg.style.color = "#ef4444";
            msg.textContent = "Server error. Try again.";
        }
    });

// =========================================================
// MARK ATTENDANCE
// =========================================================
    document.getElementById("addAttendanceForm")?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const msg = document.getElementById("attMsg");
        msg.style.color = "#94a3b8";
        msg.textContent = "Saving...";

        const body = {
            volunteerId    : parseInt(document.getElementById("att_volunteerId").value),
            eventId        : parseInt(document.getElementById("att_eventId").value),
            present        : document.getElementById("att_present").value === "true",
            attendanceDate : document.getElementById("att_date").value,
            notes          : document.getElementById("att_notes").value.trim()
        };

        try {
            const res = await fetch(`${BASE_URL}/api/attendance`, {
                method : "POST",
                headers: {
                    "Content-Type" : "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(body)
            });

            const result = await res.json();

            if (res.ok && result.success) {
                msg.style.color = "#22c55e";
                msg.textContent = "Attendance marked successfully!";
                setTimeout(() => {
                    closeModal();
                    loadAttendance(); // refresh table
                }, 1200);
            } else {
                msg.style.color = "#ef4444";
                if (result.validationErrors) {
                    msg.textContent = Object.values(result.validationErrors).join(" | ");
                } else {
                    msg.textContent = result.message || "Failed to mark attendance.";
                }
            }
        } catch (err) {
            msg.style.color = "#ef4444";
            msg.textContent = "Server error. Try again.";
        }
    });

});