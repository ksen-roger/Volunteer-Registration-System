document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");
    const message   = document.getElementById("message");

    // ── Set today's date as min for any date fields ────────────
    const today = new Date().toISOString().split("T")[0];
    document.querySelectorAll("input[type='date']").forEach(el => {
        el.setAttribute("min", today);
    });

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        // ── Read fields ────────────────────────────────────────
        const email    = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        // ── Frontend validation ────────────────────────────────
        if (!email || !password) {
            showMessage("Please enter both email and password.", "error");
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage("Please enter a valid email address.", "error");
            return;
        }

        if (password.length < 8) {
            showMessage("Password must be at least 8 characters.", "error");
            return;
        }

        // ── Show loading ───────────────────────────────────────
        showMessage("Signing in...", "loading");
        setButtonLoading(true);

        // ── Call backend ───────────────────────────────────────
        try {
            const response = await fetch("/api/auth/login", {
                method  : "POST",
                headers : { "Content-Type": "application/json" },
                body    : JSON.stringify({ email, password })
            });

            const result = await response.json();

            if (response.ok && result.success) {

                // ── Clear any old session data first ───────────
                localStorage.clear();

                // ── Save all user data to localStorage ─────────
                localStorage.setItem("accessToken",
                    result.data.accessToken);

                localStorage.setItem("refreshToken",
                    result.data.refreshToken);

                localStorage.setItem("userRole",
                    result.data.role);

                localStorage.setItem("userId",
                    result.data.userId);

                localStorage.setItem("userName",
                    result.data.firstName + " " + result.data.lastName);

                localStorage.setItem("userEmail",
                    result.data.email);

                // ── Verify token was saved correctly ───────────
                const savedToken = localStorage.getItem("accessToken");
                if (!savedToken) {
                    showMessage("Session error. Please try again.", "error");
                    setButtonLoading(false);
                    return;
                }

                // ── Show success message ───────────────────────
                showMessage("Login successful! Redirecting...", "success");

                // ── Role based redirect ────────────────────────
                const role = result.data.role;

                setTimeout(() => {
                    if (role === "ADMIN") {
                        window.location.href = "/admin-dashboard.html";
                    } else if (role === "VOLUNTEER") {
                        window.location.href = "/volunteer-dashboard.html";
                    } else {
                        // Fallback
                        window.location.href = "/dashboard.html";
                    }
                }, 800);

            } else {

                setButtonLoading(false);

                // ── Show backend error ─────────────────────────
                if (result.validationErrors) {
                    const errors = Object.values(result.validationErrors).join(" | ");
                    showMessage(errors, "error");
                } else {
                    showMessage(
                        result.message || "Invalid email or password. Please try again.",
                        "error"
                    );
                }
            }

        } catch (error) {
            console.error("Login error:", error);
            setButtonLoading(false);
            showMessage(
                "Cannot connect to server. Make sure backend is running on port 8080.",
                "error"
            );
        }
    });

    // ── Helpers ────────────────────────────────────────────────
    function showMessage(text, type) {
        if (!message) return;
        message.innerText = text;
        if (type === "success") message.style.color = "#22c55e";
        else if (type === "error") message.style.color = "#ef4444";
        else message.style.color = "#94a3b8";
    }

    function setButtonLoading(isLoading) {
        const btn = loginForm.querySelector("button[type='submit']");
        if (!btn) return;
        btn.disabled     = isLoading;
        btn.innerText    = isLoading ? "Signing in..." : "Login";
        btn.style.opacity = isLoading ? "0.7" : "1";
    }

});