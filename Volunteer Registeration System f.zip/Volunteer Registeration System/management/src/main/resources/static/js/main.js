document.addEventListener("DOMContentLoaded", () => {

    // ====================================
    // PAGE LOAD ANIMATION
    // ====================================

    document.body.style.opacity = "0";

    window.addEventListener("load", () => {
        document.body.style.transition = "opacity 0.6s ease";
        document.body.style.opacity = "1";
    });

    // ====================================
    // NAVBAR SCROLL EFFECT
    // ====================================

    const navbar = document.querySelector(".navbar");

    window.addEventListener("scroll", () => {

        if (window.scrollY > 50) {

            navbar.style.background =
                "rgba(255,255,255,0.95)";

            navbar.style.boxShadow =
                "0 8px 30px rgba(0,0,0,0.08)";

        } else {

            navbar.style.background =
                "rgba(255,255,255,0.85)";

            navbar.style.boxShadow =
                "0 4px 20px rgba(0,0,0,0.05)";
        }
    });

    // ====================================
    // COUNTER ANIMATION
    // ====================================

    const counters =
        document.querySelectorAll(".counter");

    let counterStarted = false;

    function startCounters() {

        if (counterStarted) return;

        const impactSection =
            document.querySelector(".impact");

        if (!impactSection) return;

        const sectionTop =
            impactSection.getBoundingClientRect().top;

        if (sectionTop < window.innerHeight - 100) {

            counterStarted = true;

            counters.forEach(counter => {

                const target =
                    parseInt(counter.dataset.target);

                let count = 0;

                const increment =
                    Math.ceil(target / 100);

                const updateCounter = () => {

                    count += increment;

                    if (count >= target) {

                        counter.innerText = target.toLocaleString();
                        return;
                    }

                    counter.innerText =
                        count.toLocaleString();

                    requestAnimationFrame(updateCounter);
                };

                updateCounter();
            });
        }
    }

    window.addEventListener("scroll", startCounters);

    startCounters();

    // ====================================
    // SCROLL REVEAL ANIMATION
    // ====================================

    const revealElements = document.querySelectorAll(
        ".card, .counter-card, .testimonial, .gallery img"
    );

    const revealObserver =
        new IntersectionObserver(entries => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.style.opacity = "1";

                    entry.target.style.transform =
                        "translateY(0)";

                    revealObserver.unobserve(entry.target);
                }
            });

        }, {
            threshold: 0.15
        });

    revealElements.forEach(element => {

        element.style.opacity = "0";

        element.style.transform =
            "translateY(40px)";

        element.style.transition =
            "all 0.8s ease";

        revealObserver.observe(element);
    });

    // ====================================
    // ACTIVE NAV LINK
    // ====================================

    const sections =
        document.querySelectorAll("section[id]");

    const navLinks =
        document.querySelectorAll(".nav-links a");

    window.addEventListener("scroll", () => {

        let current = "";

        sections.forEach(section => {

            const sectionTop =
                section.offsetTop - 120;

            const sectionHeight =
                section.clientHeight;

            if (
                pageYOffset >= sectionTop &&
                pageYOffset < sectionTop + sectionHeight
            ) {
                current = section.getAttribute("id");
            }
        });

        navLinks.forEach(link => {

            link.classList.remove("active");

            if (
                link.getAttribute("href") ===
                "#" + current
            ) {
                link.classList.add("active");
            }
        });
    });

    // ====================================
    // GALLERY HOVER EFFECT
    // ====================================

    const galleryImages =
        document.querySelectorAll(".gallery img");

    galleryImages.forEach(img => {

        img.addEventListener("mouseenter", () => {

            img.style.transform =
                "scale(1.08)";
        });

        img.addEventListener("mouseleave", () => {

            img.style.transform =
                "scale(1)";
        });
    });

    // ====================================
    // PARALLAX HERO IMAGE
    // ====================================

    const heroImage =
        document.querySelector(".hero-image img");

    if (heroImage) {

        window.addEventListener("mousemove", e => {

            const x =
                (window.innerWidth / 2 - e.clientX) / 40;

            const y =
                (window.innerHeight / 2 - e.clientY) / 40;

            heroImage.style.transform =
                `translate(${x}px, ${y}px)`;
        });
    }

});