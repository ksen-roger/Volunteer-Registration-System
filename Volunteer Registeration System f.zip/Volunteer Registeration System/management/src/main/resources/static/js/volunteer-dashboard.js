'use strict';
/* ================================================================
   VOLUNTEER-DASHBOARD.JS  —  NaayePank Foundation
   Fixes: nav switching, API data loading, apply flow, profile save
================================================================ */

const BASE = 'http://localhost:8080';

/* ── Read auth ─────────────────────────────────────────────── */
const token    = localStorage.getItem('accessToken');
const userName = localStorage.getItem('userName')  || 'Volunteer';
const userId   = localStorage.getItem('userId');

/* ── AUTH GUARD — redirect if no token ─────────────────────── */
if (!token) {
    window.location.replace('login.html');
    throw new Error('Not authenticated');
}

/* ================================================================
   DOM READY
================================================================ */
document.addEventListener('DOMContentLoaded', function () {

    /* ── Populate user info ──────────────────────────────────── */
    var first = userName.split(' ')[0];
    setText('userName',     first);
    setText('userNameTop',  userName);
    setText('userInitial',  (userName[0] || 'V').toUpperCase());

    /* ── Sidebar navigation ──────────────────────────────────── */
    var navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(function (item) {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            var sectionId = item.getAttribute('data-section');
            if (sectionId) {
                showSection(sectionId);
                /* close mobile sidebar */
                document.getElementById('sidebar').classList.remove('open');
                document.getElementById('sidebarOverlay').classList.remove('show');
            }
        });
    });

    /* ── Hamburger ───────────────────────────────────────────── */
    var hamburger = document.getElementById('hamburger');
    var sidebar   = document.getElementById('sidebar');
    var overlay   = document.getElementById('sidebarOverlay');

    if (hamburger) {
        hamburger.addEventListener('click', function () {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('show');
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function () {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        });
    }

    /* ── Logout ──────────────────────────────────────────────── */
    var logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
            localStorage.clear();
            window.location.replace('login.html');
        });
    }

    /* ── Profile form ────────────────────────────────────────── */
    var profileForm = document.getElementById('volunteerForm');
    if (profileForm) {
        profileForm.addEventListener('submit', submitProfile);
    }

    /* ── Apply confirm ───────────────────────────────────────── */
    var confirmBtn = document.getElementById('confirmApplyBtn');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', confirmApply);
    }

    /* ── Modal overlay click to close ───────────────────────── */
    var applyModal = document.getElementById('applyModal');
    if (applyModal) {
        applyModal.addEventListener('click', function (e) {
            if (e.target === applyModal) closeModal();
        });
    }

    /* ── Load initial data ───────────────────────────────────── */
    loadDashboard();
});

/* ================================================================
   SECTION SWITCHING
================================================================ */
window.showSection = function (sectionId) {
    /* hide all */
    document.querySelectorAll('.dash-section').forEach(function (s) {
        s.classList.remove('active-section');
    });
    /* show target */
    var target = document.getElementById(sectionId);
    if (target) target.classList.add('active-section');

    /* update active nav item */
    document.querySelectorAll('.nav-item').forEach(function (item) {
        var s = item.getAttribute('data-section');
        item.classList.toggle('active', s === sectionId);
    });

    /* lazy-load section data */
    if (sectionId === 'eventsSection')       loadEvents('eventsTableBody');
    if (sectionId === 'myAppsSection')       loadMyApplications();
    if (sectionId === 'myAttendanceSection') loadMyAttendance();
    if (sectionId === 'profileSection')      loadMyProfile();
};

/* ================================================================
   API HELPER
================================================================ */
function api(path, method, body) {
    method = method || 'GET';
    var opts = {
        method: method,
        headers: {
            'Content-Type':  'application/json',
            'Authorization': 'Bearer ' + token
        }
    };
    if (body) opts.body = JSON.stringify(body);

    return fetch(BASE + path, opts).then(function (res) {
        if (res.status === 401 || res.status === 403) {
            localStorage.clear();
            window.location.replace('login.html');
            return null;
        }
        return res.json().then(function (data) {
            return { ok: res.ok, status: res.status, data: data };
        });
    });
}

/* ================================================================
   DASHBOARD — load stats + preview tables
================================================================ */
function loadDashboard() {
    /* Stats from applications */
    if (userId) {
        api('/api/applications?volunteerId=' + userId + '&page=0&size=100')
            .then(function (r) {
                if (!r) return;
                var list = (r.data && r.data.data && r.data.data.content)
                    || (r.data && r.data.content) || [];
                setText('myApplications', list.length);
                var pending  = list.filter(function (a) { return a.status === 'PENDING'; }).length;
                var approved = list.filter(function (a) { return a.status === 'APPROVED'; }).length;
                setText('pendingApps',  pending);
                setText('approvedApps', approved);

                /* Render preview in dashboard section */
                renderAppsTable('dashAppsBody', list.slice(0, 5), 5);
            }).catch(function (e) { console.error('apps error', e); });
    }

    /* Total events count */
    api('/api/events?page=0&size=1').then(function (r) {
        if (!r) return;
        var total = (r.data && r.data.data && r.data.data.totalElements)
            || (r.data && r.data.totalElements) || 0;
        setText('totalEvents', total);
    }).catch(function (e) { console.error('events count error', e); });

    /* Events preview table on dashboard */
    loadEvents('dashEventsBody', 5);
}

/* ================================================================
   EVENTS TABLE
================================================================ */
window.loadEvents = function (tbodyId, limit) {
    tbodyId = tbodyId || 'eventsTableBody';
    limit   = limit   || 20;

    var tbody = document.getElementById(tbodyId);
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="7" class="tbl-empty">Loading events...</td></tr>';

    api('/api/events?page=0&size=' + limit + '&sortBy=eventId&sortDir=desc')
        .then(function (r) {
            if (!r) return;
            var events = (r.data && r.data.data && r.data.data.content)
                || (r.data && r.data.content) || [];

            if (!events.length) {
                tbody.innerHTML = '<tr><td colspan="7" class="tbl-empty">No events available right now.</td></tr>';
                return;
            }

            tbody.innerHTML = '';
            events.forEach(function (ev) {
                if (!ev.active) return;
                var tr = document.createElement('tr');
                var dt = ev.eventDate ? new Date(ev.eventDate).toLocaleDateString('en-IN', {
                    day: '2-digit', month: 'short', year: 'numeric'
                }) : '—';

                /* 7 cols for full table, 6 for dashboard preview */
                var idCol = tbodyId === 'dashEventsBody'
                    ? '<td>' + ev.eventId + '</td>'
                    : '<td>' + ev.eventId + '</td>';

                tr.innerHTML = idCol +
                    '<td><div style="font-weight:600;color:#e2e8f0">' + esc(ev.eventName) + '</div></td>' +
                    '<td>' + esc(ev.location) + '</td>' +
                    '<td>' + dt + '</td>' +
                    '<td>' + (ev.requiredVolunteers || '—') + '</td>' +
                    '<td>' + esc(ev.organizer || '—') + '</td>' +
                    '<td><button class="btn-apply" onclick="openApplyModal(' +
                    ev.eventId + ',\'' + esc(ev.eventName) + '\')">Apply</button></td>';
                tbody.appendChild(tr);
            });
        }).catch(function (e) {
        console.error('events error', e);
        tbody.innerHTML = '<tr><td colspan="7" class="tbl-empty" style="color:#f87171">Failed to load. Check console.</td></tr>';
    });
};

/* ================================================================
   MY APPLICATIONS
================================================================ */
window.loadMyApplications = function () {
    if (!userId) {
        setText('myAppsTableBody', '');
        var b = document.getElementById('myAppsTableBody');
        if (b) b.innerHTML = '<tr><td colspan="6" class="tbl-empty">No volunteer profile found. Please save your profile first.</td></tr>';
        return;
    }

    var tbody = document.getElementById('myAppsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" class="tbl-empty">Loading...</td></tr>';

    api('/api/applications?volunteerId=' + userId + '&page=0&size=50')
        .then(function (r) {
            if (!r) return;
            var list = (r.data && r.data.data && r.data.data.content)
                || (r.data && r.data.content) || [];
            renderAppsTable('myAppsTableBody', list, 6);
        }).catch(function (e) {
        console.error('my apps error', e);
        var tb = document.getElementById('myAppsTableBody');
        if (tb) tb.innerHTML = '<tr><td colspan="6" class="tbl-empty" style="color:#f87171">Failed to load applications.</td></tr>';
    });
};

function renderAppsTable(tbodyId, list, cols) {
    var tbody = document.getElementById(tbodyId);
    if (!tbody) return;

    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="' + cols + '" class="tbl-empty">No applications yet. Browse events and apply!</td></tr>';
        return;
    }

    tbody.innerHTML = '';
    list.forEach(function (app) {
        var tr = document.createElement('tr');
        var applied = app.appliedDate ? new Date(app.appliedDate).toLocaleDateString('en-IN') : '—';
        var evtDate = app.eventDate   ? new Date(app.eventDate).toLocaleDateString('en-IN')   : '—';
        var badge   = '<span class="badge badge-' + (app.status || 'pending').toLowerCase() + '">' + (app.status || '—') + '</span>';

        tr.innerHTML =
            '<td>' + (app.id || '—') + '</td>' +
            '<td><div style="font-weight:600">' + esc(app.eventName || '—') + '</div></td>' +
            '<td>' + esc(app.eventLocation || '—') + '</td>' +
            '<td>' + evtDate + '</td>' +
            '<td>' + applied + '</td>' +
            '<td>' + badge + '</td>';
        tbody.appendChild(tr);
    });
}

/* ================================================================
   MY ATTENDANCE
================================================================ */
window.loadMyAttendance = function () {
    if (!userId) return;
    var tbody = document.getElementById('myAttendanceBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="4" class="tbl-empty">Loading...</td></tr>';

    api('/api/attendance?volunteerId=' + userId + '&page=0&size=50')
        .then(function (r) {
            if (!r) return;
            var list = (r.data && r.data.data && r.data.data.content)
                || (r.data && r.data.content) || [];

            if (!list.length) {
                tbody.innerHTML = '<tr><td colspan="4" class="tbl-empty">No attendance records yet.</td></tr>';
                return;
            }

            tbody.innerHTML = '';
            list.forEach(function (a) {
                var tr = document.createElement('tr');
                var dt = a.attendanceDate ? new Date(a.attendanceDate).toLocaleDateString('en-IN') : '—';
                var badge = a.present
                    ? '<span class="badge badge-present">Present</span>'
                    : '<span class="badge badge-absent">Absent</span>';
                tr.innerHTML =
                    '<td>' + a.attendanceId + '</td>' +
                    '<td>' + esc(a.eventName || '—') + '</td>' +
                    '<td>' + dt + '</td>' +
                    '<td>' + badge + '</td>';
                tbody.appendChild(tr);
            });
        }).catch(function (e) {
        console.error('attendance error', e);
        tbody.innerHTML = '<tr><td colspan="4" class="tbl-empty" style="color:#f87171">Failed to load.</td></tr>';
    });
};

/* ================================================================
   MY PROFILE — load & save
================================================================ */
function loadMyProfile() {
    if (!userId) return;
    api('/api/volunteers/' + userId)
        .then(function (r) {
            if (!r || !r.ok) return;
            var v = (r.data && r.data.data) || r.data || {};
            setVal('firstName',        v.firstName        || '');
            setVal('lastName',         v.lastName         || '');
            setVal('email',            v.email            || '');
            setVal('phone',            v.phone            || '');
            setVal('age',              v.age              || '');
            setVal('gender',           v.gender           || '');
            setVal('availability',     v.availability     || '');
            setVal('skills',           v.skills           || '');
            setVal('address',          v.address          || '');
            setVal('emergencyContact', v.emergencyContact || '');
        }).catch(function (e) { console.error('profile load error', e); });
}

function submitProfile(e) {
    e.preventDefault();
    var msg = document.getElementById('profileMessage');
    showMsg(msg, 'Saving...', '#94a3b8');

    var body = {
        firstName:        getVal('firstName'),
        lastName:         getVal('lastName'),
        email:            getVal('email'),
        phone:            getVal('phone'),
        age:              parseInt(getVal('age')) || 0,
        gender:           getVal('gender'),
        availability:     getVal('availability'),
        skills:           getVal('skills'),
        address:          getVal('address'),
        emergencyContact: getVal('emergencyContact'),
        registrationDate: new Date().toISOString().split('T')[0]
    };

    /* POST = create, but if volunteerId in localStorage, try PUT */
    var volunteerId = localStorage.getItem('volunteerId');
    var method = volunteerId ? 'PUT'  : 'POST';
    var path   = volunteerId ? '/api/volunteers/' + volunteerId : '/api/volunteers';

    api(path, method, body).then(function (r) {
        if (!r) return;
        if (r.ok) {
            var v = (r.data && r.data.data) || r.data || {};
            if (v.volunteerId) localStorage.setItem('volunteerId', v.volunteerId);
            showMsg(msg, 'Profile saved successfully!', '#10b981');
            toast('Profile saved!', 'success');
        } else {
            var err = flatErr(r.data);
            showMsg(msg, err, '#f87171');
            toast(err, 'error');
        }
    }).catch(function (e) {
        console.error('profile save error', e);
        showMsg(msg, 'Server error. Try again.', '#f87171');
    });
}

/* ================================================================
   APPLY FOR EVENT
================================================================ */
window.openApplyModal = function (eventId, eventName) {
    var modal = document.getElementById('applyModal');
    var nameEl = document.getElementById('applyEventName');
    var idEl   = document.getElementById('applyEventId');
    var msgEl  = document.getElementById('applyMsg');

    if (nameEl) nameEl.textContent = eventName;
    if (idEl)   idEl.value = eventId;
    if (msgEl)  msgEl.textContent = '';
    if (modal)  modal.classList.add('open');
};

window.closeModal = function () {
    var modal = document.getElementById('applyModal');
    if (modal) modal.classList.remove('open');
};

function confirmApply() {
    var eventId = document.getElementById('applyEventId').value;
    var msgEl   = document.getElementById('applyMsg');
    var volId   = localStorage.getItem('volunteerId') || userId;

    if (!volId) {
        showMsg(msgEl, 'Please save your profile first before applying.', '#f87171');
        return;
    }

    showMsg(msgEl, 'Submitting...', '#94a3b8');
    document.getElementById('confirmApplyBtn').disabled = true;

    api('/api/applications', 'POST', {
        volunteerId: parseInt(volId),
        eventId:     parseInt(eventId)
    }).then(function (r) {
        document.getElementById('confirmApplyBtn').disabled = false;
        if (!r) return;
        if (r.ok) {
            closeModal();
            toast('Applied successfully!', 'success');
            loadDashboard();
        } else {
            showMsg(msgEl, flatErr(r.data), '#f87171');
            toast(flatErr(r.data), 'error');
        }
    }).catch(function (e) {
        document.getElementById('confirmApplyBtn').disabled = false;
        console.error('apply error', e);
        showMsg(msgEl, 'Server error. Try again.', '#f87171');
    });
}

/* ================================================================
   UTILITIES
================================================================ */
function setText(id, val) {
    var el = document.getElementById(id);
    if (el) el.textContent = (val !== undefined && val !== null) ? val : '—';
}
function setVal(id, val) {
    var el = document.getElementById(id);
    if (el) el.value = val || '';
}
function getVal(id) {
    var el = document.getElementById(id);
    return el ? el.value.trim() : '';
}
function esc(s) {
    if (!s) return '';
    return String(s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function flatErr(data) {
    if (!data) return 'Something went wrong.';
    if (data.validationErrors) return Object.values(data.validationErrors).join(' | ');
    return data.message || 'Operation failed.';
}
function showMsg(el, text, color) {
    if (!el) return;
    el.textContent = text;
    el.style.color = color || '#94a3b8';
}

function toast(message, type) {
    var stack = document.getElementById('toastStack');
    if (!stack) return;
    var icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️' };
    type = type || 'info';
    var div = document.createElement('div');
    div.className = 'toast toast-' + type;
    div.innerHTML =
        '<span class="toast-icon">' + (icons[type] || 'ℹ️') + '</span>' +
        '<span class="toast-msg">' + esc(message) + '</span>' +
        '<button class="toast-close" onclick="this.closest(\'.toast\').remove()">&#10005;</button>';
    stack.appendChild(div);
    setTimeout(function () {
        div.classList.add('out');
        setTimeout(function () { div.remove(); }, 280);
    }, 3500);
}