package com.volunteer.management.service.impl;

import com.volunteer.management.dto.request.ApplicationStatusRequest;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerEventResponse;
import com.volunteer.management.model.Event;
import com.volunteer.management.model.Volunteer;
import com.volunteer.management.model.VolunteerEvent;
import com.volunteer.management.enums.ApplicationStatus;
import com.volunteer.management.exception.BadRequestException;
import com.volunteer.management.exception.DuplicateResourceException;
import com.volunteer.management.exception.ResourceNotFoundException;
import com.volunteer.management.mapper.VolunteerEventMapper;
import com.volunteer.management.repository.EventRepository;
import com.volunteer.management.repository.VolunteerEventRepository;
import com.volunteer.management.repository.VolunteerRepository;
import com.volunteer.management.service.VolunteerEventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class VolunteerEventServiceImpl implements VolunteerEventService {

    private final VolunteerEventRepository volunteerEventRepository;
    private final VolunteerRepository volunteerRepository;
    private final EventRepository eventRepository;
    private final VolunteerEventMapper volunteerEventMapper;

    @Override
    @Transactional
    public VolunteerEventResponse applyForEvent(Long volunteerId, Long eventId) {
        Volunteer volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Volunteer", "id", volunteerId));

        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Event", "id", eventId));

        if (!event.isActive()) {
            throw new BadRequestException("Event is no longer active");
        }

        if (volunteerEventRepository
                .existsByVolunteerVolunteerIdAndEventEventId(volunteerId, eventId)) {
            throw new DuplicateResourceException("Already applied for this event");
        }

        long approved = volunteerEventRepository.countApprovedVolunteersForEvent(eventId);
        if (approved >= event.getRequiredVolunteers()) {
            throw new BadRequestException("Event has reached its volunteer capacity");
        }

        VolunteerEvent ve = VolunteerEvent.builder()
                .volunteer(volunteer)
                .event(event)
                .status(ApplicationStatus.PENDING)
                .build();

        VolunteerEvent saved = volunteerEventRepository.save(ve);
        log.info("Volunteer {} applied for event {}", volunteerId, eventId);
        return volunteerEventMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public VolunteerEventResponse updateStatus(
            Long applicationId, ApplicationStatusRequest request, String reviewerEmail) {
        VolunteerEvent ve = findById(applicationId);

        if (ve.getStatus() != ApplicationStatus.PENDING) {
            throw new BadRequestException("Only PENDING applications can be reviewed");
        }

        ve.setStatus(request.getStatus());
        ve.setReviewedDate(LocalDateTime.now());
        ve.setReviewedBy(reviewerEmail);
        ve.setRemarks(request.getRemarks());

        VolunteerEvent updated = volunteerEventRepository.save(ve);
        log.info("Application {} status updated to {}", applicationId, request.getStatus());
        return volunteerEventMapper.toResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public VolunteerEventResponse getById(Long id) {
        return volunteerEventMapper.toResponse(findById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<VolunteerEventResponse> getApplications(
            Long volunteerId, Long eventId, ApplicationStatus status,
            int page, int size, String sortBy, String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<VolunteerEvent> result = volunteerEventRepository
                .findApplications(volunteerId, eventId, status, pageable);

        return PagedResponse.<VolunteerEventResponse>builder()
                .content(result.getContent().stream()
                        .map(volunteerEventMapper::toResponse).toList())
                .pageNumber(result.getNumber())
                .pageSize(result.getSize())
                .totalElements(result.getTotalElements())
                .totalPages(result.getTotalPages())
                .last(result.isLast())
                .first(result.isFirst())
                .build();
    }

    @Override
    @Transactional
    public void withdraw(Long applicationId, Long volunteerId) {
        VolunteerEvent ve = findById(applicationId);

        if (!ve.getVolunteer().getVolunteerId().equals(volunteerId)) {
            throw new BadRequestException(
                    "You are not authorized to withdraw this application");
        }

        if (ve.getStatus() != ApplicationStatus.PENDING) {
            throw new BadRequestException("Only PENDING applications can be withdrawn");
        }

        volunteerEventRepository.delete(ve);
        log.info("Application {} withdrawn", applicationId);
    }

    private VolunteerEvent findById(Long id) {
        return volunteerEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Application", "id", id));
    }
}
