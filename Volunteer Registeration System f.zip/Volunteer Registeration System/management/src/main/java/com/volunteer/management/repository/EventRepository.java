package com.volunteer.management.repository;


import com.volunteer.management.model.Event;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    List<Event> findAllByActiveTrue();

    @Query("""
        SELECT e FROM Event e
        WHERE (:search IS NULL
               OR LOWER(e.eventName)  LIKE LOWER(CONCAT('%',:search,'%'))
               OR LOWER(e.location)   LIKE LOWER(CONCAT('%',:search,'%'))
               OR LOWER(e.organizer)  LIKE LOWER(CONCAT('%',:search,'%')))
          AND (:fromDate IS NULL OR e.eventDate >= :fromDate)
          AND (:toDate   IS NULL OR e.eventDate <= :toDate)
          AND (:active   IS NULL OR e.active    =  :active)
        """)
    Page<Event> searchEvents(
            @Param("search")   String search,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate")   LocalDate toDate,
            @Param("active")   Boolean active,
            Pageable pageable);
}
