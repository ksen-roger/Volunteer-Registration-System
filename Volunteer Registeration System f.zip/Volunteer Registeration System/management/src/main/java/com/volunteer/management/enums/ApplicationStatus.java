package com.volunteer.management.enums;

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
