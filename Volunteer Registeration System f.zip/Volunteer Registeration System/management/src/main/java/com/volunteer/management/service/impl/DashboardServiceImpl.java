package com.volunteer.management.service.impl;

import com.volunteer.management.dto.response.DashboardResponse;
import com.volunteer.management.enums.ApplicationStatus;
import com.volunteer.management.repository.AttendanceRepository;
import com.volunteer.management.repository.EventRepository;
import com.volunteer.management.repository.UserRepository;
import com.volunteer.management.repository.VolunteerEventRepository;
import com.volunteer.management.repository.VolunteerRepository;
import com.volunteer.management.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final VolunteerRepository volunteerRepository;
    private final EventRepository eventRepository;
    private final VolunteerEventRepository volunteerEventRepository;
    private final AttendanceRepository attendanceRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public DashboardResponse getStats() {
        return DashboardResponse.builder()
                .totalVolunteers(volunteerRepository.count())
                .totalEvents(eventRepository.count())
                .activeEvents(eventRepository.findAllByActiveTrue().size())
                .totalApplications(volunteerEventRepository.count())
                .pendingApplications(
                        volunteerEventRepository.countByStatus(ApplicationStatus.PENDING))
                .approvedApplications(
                        volunteerEventRepository.countByStatus(ApplicationStatus.APPROVED))
                .rejectedApplications(
                        volunteerEventRepository.countByStatus(ApplicationStatus.REJECTED))
                .totalAttendanceRecords(attendanceRepository.count())
                .presentCount(attendanceRepository.countByPresentTrue())
                .totalUsers(userRepository.count())
                .build();
    }
}