package com.volunteer.management.service;


import com.volunteer.management.dto.request.AttendanceRequest;
import com.volunteer.management.dto.response.AttendanceResponse;
import com.volunteer.management.dto.response.PagedResponse;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceService {

    AttendanceResponse markAttendance(AttendanceRequest request);

    AttendanceResponse updateAttendance(Long id, AttendanceRequest request);

    AttendanceResponse getAttendanceById(Long id);

    PagedResponse<AttendanceResponse> getAttendances(
            Long volunteerId, Long eventId, LocalDate fromDate, LocalDate toDate,
            Boolean present, int page, int size, String sortBy, String sortDir);

    List<AttendanceResponse> getAllForReport();
}
