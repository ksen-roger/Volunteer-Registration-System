package com.volunteer.management.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EventRequest {

    @NotBlank(message = "Event name is required")
    @Size(min = 3, max = 100)
    private String eventName;

    @Size(max = 1000)
    private String description;

    @NotBlank(message = "Location is required")
    @Size(max = 255)
    private String location;

    @NotNull(message = "Event date is required")
    @Future(message = "Event date must be in the future")
    private LocalDate eventDate;

    @NotNull(message = "Required volunteers count is required")
    @Positive(message = "Must be a positive number")
    @Max(value = 10000)
    private Integer requiredVolunteers;

    @NotBlank(message = "Organizer is required")
    @Size(max = 100)
    private String organizer;
}