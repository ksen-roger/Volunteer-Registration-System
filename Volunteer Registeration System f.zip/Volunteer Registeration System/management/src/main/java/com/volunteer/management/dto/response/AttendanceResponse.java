package com.volunteer.management.dto.response;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceResponse {

    private Long attendanceId;
    private Long volunteerId;
    private String volunteerName;
    private String volunteerEmail;
    private Long eventId;
    private String eventName;
    private boolean present;
    private LocalDate attendanceDate;
    private String notes;
    private LocalDateTime createdAt;
}
