package com.volunteer.management.service;


import com.volunteer.management.dto.request.ApplicationStatusRequest;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerEventResponse;
import com.volunteer.management.enums.ApplicationStatus;

public interface VolunteerEventService {

    VolunteerEventResponse applyForEvent(Long volunteerId, Long eventId);

    VolunteerEventResponse updateStatus(
            Long applicationId, ApplicationStatusRequest request, String reviewerEmail);

    VolunteerEventResponse getById(Long id);

    PagedResponse<VolunteerEventResponse> getApplications(
            Long volunteerId, Long eventId, ApplicationStatus status,
            int page, int size, String sortBy, String sortDir);

    void withdraw(Long applicationId, Long volunteerId);
}
