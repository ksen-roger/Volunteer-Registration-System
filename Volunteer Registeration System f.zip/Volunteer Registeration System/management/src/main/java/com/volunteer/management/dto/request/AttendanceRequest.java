package com.volunteer.management.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceRequest {

    @NotNull(message = "Volunteer ID is required")
    private Long volunteerId;

    @NotNull(message = "Event ID is required")
    private Long eventId;

    @NotNull(message = "Attendance status is required")
    private Boolean present;

    @NotNull(message = "Attendance date is required")
    @PastOrPresent(message = "Attendance date cannot be in the future")
    private LocalDate attendanceDate;

    private String notes;
}
