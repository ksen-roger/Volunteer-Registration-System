package com.volunteer.management.mapper;

import com.volunteer.management.dto.request.EventRequest;
import com.volunteer.management.dto.response.EventResponse;
import com.volunteer.management.model.Event;
import com.volunteer.management.repository.VolunteerEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EventMapper {

    private final VolunteerEventRepository volunteerEventRepository;

    public Event toEntity(EventRequest req) {
        return Event.builder()
                .eventName(req.getEventName())
                .description(req.getDescription())
                .location(req.getLocation())
                .eventDate(req.getEventDate())
                .requiredVolunteers(req.getRequiredVolunteers())
                .organizer(req.getOrganizer())
                .build();
    }

    public EventResponse toResponse(Event e) {
        long approved = volunteerEventRepository
                .countApprovedVolunteersForEvent(e.getEventId());

        return EventResponse.builder()
                .eventId(e.getEventId())
                .eventName(e.getEventName())
                .description(e.getDescription())
                .location(e.getLocation())
                .eventDate(e.getEventDate())
                .requiredVolunteers(e.getRequiredVolunteers())
                .approvedVolunteersCount(approved)
                .organizer(e.getOrganizer())
                .active(e.isActive())
                .createdAt(e.getCreatedAt())
                .build();
    }

    public void update(EventRequest req, Event e) {
        e.setEventName(req.getEventName());
        e.setDescription(req.getDescription());
        e.setLocation(req.getLocation());
        e.setEventDate(req.getEventDate());
        e.setRequiredVolunteers(req.getRequiredVolunteers());
        e.setOrganizer(req.getOrganizer());
    }
}