package com.volunteer.management.mapper;

import com.volunteer.management.dto.response.VolunteerEventResponse;
import com.volunteer.management.model.VolunteerEvent;
import org.springframework.stereotype.Component;

@Component
public class VolunteerEventMapper {

    public VolunteerEventResponse toResponse(VolunteerEvent ve) {
        return VolunteerEventResponse.builder()
                .id(ve.getId())
                .volunteerId(ve.getVolunteer().getVolunteerId())
                .volunteerName(
                        ve.getVolunteer().getFirstName() + " "
                                + ve.getVolunteer().getLastName())
                .volunteerEmail(ve.getVolunteer().getEmail())
                .eventId(ve.getEvent().getEventId())
                .eventName(ve.getEvent().getEventName())
                .eventLocation(ve.getEvent().getLocation())
                .status(ve.getStatus())
                .appliedDate(ve.getAppliedDate())
                .reviewedDate(ve.getReviewedDate())
                .reviewedBy(ve.getReviewedBy())
                .remarks(ve.getRemarks())
                .build();
    }
}