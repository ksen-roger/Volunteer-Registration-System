package com.volunteer.management.dto.response;

import com.volunteer.management.enums.Role;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {

    private String accessToken;
    private String refreshToken;

    @Builder.Default
    private String tokenType = "Bearer";

    private Long expiresIn;
    private Long userId;
    private String email;
    private String firstName;
    private String lastName;
    private Role role;
}
