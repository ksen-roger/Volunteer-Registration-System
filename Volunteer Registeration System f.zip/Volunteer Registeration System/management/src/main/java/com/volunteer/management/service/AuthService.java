package com.volunteer.management.service;

import com.volunteer.management.dto.request.LoginRequest;
import com.volunteer.management.dto.request.RegisterRequest;
import com.volunteer.management.dto.response.AuthResponse;

public interface AuthService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);
}
