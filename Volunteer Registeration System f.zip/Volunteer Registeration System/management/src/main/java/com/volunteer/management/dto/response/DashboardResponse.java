package com.volunteer.management.dto.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardResponse {

    private long totalVolunteers;
    private long totalEvents;
    private long activeEvents;
    private long totalApplications;
    private long pendingApplications;
    private long approvedApplications;
    private long rejectedApplications;
    private long totalAttendanceRecords;
    private long presentCount;
    private long totalUsers;
}
