package com.volunteer.management.enums;

public enum Availability {
    WEEKDAYS,
    WEEKENDS,
    BOTH,
    FLEXIBLE
}
