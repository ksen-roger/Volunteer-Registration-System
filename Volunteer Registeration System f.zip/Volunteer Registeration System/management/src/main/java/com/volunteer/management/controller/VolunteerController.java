package com.volunteer.management.controller;

import com.volunteer.management.dto.request.VolunteerRequest;
import com.volunteer.management.dto.response.ApiResponse;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerResponse;
import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;
import com.volunteer.management.service.VolunteerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/volunteers")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Volunteer Management", description = "CRUD and search for volunteers")
public class VolunteerController {

    private final VolunteerService volunteerService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Register a new volunteer profile")
    public ResponseEntity<ApiResponse<VolunteerResponse>> create(
            @Valid @RequestBody VolunteerRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Volunteer registered",
                        volunteerService.createVolunteer(request, userDetails.getUsername())));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update volunteer profile")
    public ResponseEntity<ApiResponse<VolunteerResponse>> update(
            @PathVariable Long id, @Valid @RequestBody VolunteerRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Volunteer updated",
                volunteerService.updateVolunteer(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete volunteer")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        volunteerService.deleteVolunteer(id);
        return ResponseEntity.ok(ApiResponse.<Void>success("Volunteer deleted"));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Get volunteer by ID")
    public ResponseEntity<ApiResponse<VolunteerResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Volunteer retrieved",
                volunteerService.getVolunteerById(id)));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "List all volunteers with pagination and sorting")
    public ResponseEntity<ApiResponse<PagedResponse<VolunteerResponse>>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "volunteerId") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        return ResponseEntity.ok(ApiResponse.success("Volunteers retrieved",
                volunteerService.getAllVolunteers(page, size, sortBy, sortDir)));
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Search volunteers by name, email, skills, gender, or availability")
    public ResponseEntity<ApiResponse<PagedResponse<VolunteerResponse>>> search(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Gender gender,
            @RequestParam(required = false) Availability availability,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "volunteerId") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        return ResponseEntity.ok(ApiResponse.success("Search results",
                volunteerService.searchVolunteers(search, gender, availability,
                        page, size, sortBy, sortDir)));
    }
}