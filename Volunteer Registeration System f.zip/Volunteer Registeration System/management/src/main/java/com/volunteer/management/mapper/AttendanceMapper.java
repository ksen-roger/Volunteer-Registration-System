package com.volunteer.management.mapper;

import com.volunteer.management.dto.response.AttendanceResponse;
import com.volunteer.management.model.Attendance;
import org.springframework.stereotype.Component;

@Component
public class AttendanceMapper {

    public AttendanceResponse toResponse(Attendance a) {
        return AttendanceResponse.builder()
                .attendanceId(a.getAttendanceId())
                .volunteerId(a.getVolunteer().getVolunteerId())
                .volunteerName(
                        a.getVolunteer().getFirstName() + " "
                                + a.getVolunteer().getLastName())
                .volunteerEmail(a.getVolunteer().getEmail())
                .eventId(a.getEvent().getEventId())
                .eventName(a.getEvent().getEventName())
                .present(a.isPresent())
                .attendanceDate(a.getAttendanceDate())
                .notes(a.getNotes())
                .createdAt(a.getCreatedAt())
                .build();
    }
}