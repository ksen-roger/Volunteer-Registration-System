package com.volunteer.management.repository;


import com.volunteer.management.model.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    boolean existsByVolunteerVolunteerIdAndEventEventIdAndAttendanceDate(
            Long volunteerId, Long eventId, LocalDate date);

    Optional<Attendance> findByVolunteerVolunteerIdAndEventEventIdAndAttendanceDate(
            Long volunteerId, Long eventId, LocalDate date);

    List<Attendance> findByEventEventId(Long eventId);

    List<Attendance> findByVolunteerVolunteerId(Long volunteerId);

    long countByPresentTrue();

    @Query("""
        SELECT a FROM Attendance a
        WHERE (:volunteerId IS NULL OR a.volunteer.volunteerId = :volunteerId)
          AND (:eventId     IS NULL OR a.event.eventId         = :eventId)
          AND (:fromDate    IS NULL OR a.attendanceDate        >= :fromDate)
          AND (:toDate      IS NULL OR a.attendanceDate        <= :toDate)
          AND (:present     IS NULL OR a.present               = :present)
        """)
    Page<Attendance> searchAttendance(
            @Param("volunteerId") Long volunteerId,
            @Param("eventId")     Long eventId,
            @Param("fromDate")    LocalDate fromDate,
            @Param("toDate")      LocalDate toDate,
            @Param("present")     Boolean present,
            Pageable pageable);
}
