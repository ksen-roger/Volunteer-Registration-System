package com.volunteer.management.repository;

import com.volunteer.management.model.VolunteerEvent;
import com.volunteer.management.enums.ApplicationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VolunteerEventRepository extends JpaRepository<VolunteerEvent, Long> {

    boolean existsByVolunteerVolunteerIdAndEventEventId(
            Long volunteerId, Long eventId);

    Optional<VolunteerEvent> findByVolunteerVolunteerIdAndEventEventId(
            Long volunteerId, Long eventId);

    long countByStatus(ApplicationStatus status);

    @Query("""
        SELECT COUNT(ve) FROM VolunteerEvent ve
        WHERE ve.event.eventId = :eventId
          AND ve.status = 'APPROVED'
        """)
    long countApprovedVolunteersForEvent(
            @Param("eventId") Long eventId);

    @Query("""
        SELECT ve FROM VolunteerEvent ve
        WHERE (:volunteerId IS NULL OR ve.volunteer.volunteerId = :volunteerId)
          AND (:eventId     IS NULL OR ve.event.eventId         = :eventId)
          AND (:status      IS NULL OR ve.status                = :status)
        """)
    Page<VolunteerEvent> findApplications(
            @Param("volunteerId") Long volunteerId,
            @Param("eventId")     Long eventId,
            @Param("status")      ApplicationStatus status,
            Pageable pageable);
}
