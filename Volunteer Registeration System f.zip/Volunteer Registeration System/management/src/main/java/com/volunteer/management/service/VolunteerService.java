package com.volunteer.management.service;

import com.volunteer.management.dto.request.VolunteerRequest;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerResponse;
import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;

import java.util.List;

public interface VolunteerService {

    VolunteerResponse createVolunteer(VolunteerRequest request, String userEmail);

    VolunteerResponse updateVolunteer(Long id, VolunteerRequest request);

    void deleteVolunteer(Long id);

    VolunteerResponse getVolunteerById(Long id);

    VolunteerResponse getVolunteerByEmail(String email);

    PagedResponse<VolunteerResponse> getAllVolunteers(
            int page, int size, String sortBy, String sortDir);

    PagedResponse<VolunteerResponse> searchVolunteers(
            String search, Gender gender, Availability availability,
            int page, int size, String sortBy, String sortDir);

    List<VolunteerResponse> getAllForReport();
}