package com.volunteer.management.config;

import com.volunteer.management.security.CustomUserDetailsService;
import com.volunteer.management.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final CustomUserDetailsService userDetailsService;

    private static final String[] WHITE_LIST = {

            // Frontend Pages — must match EXACT file names served from /static
            "/",
            "/index.html",
            "/login.html",
            "/register.html",
            "/admin-dashboard.html",
            "/volunteer-dashboard.html",

            // Static Resources
            "/css/**",
            "/js/**",
            "/images/**",
            "/fonts/**",
            "/favicon.ico",

            // Auth APIs
            "/api/auth/**",

            // Swagger
            "/swagger-ui/**",
            "/swagger-ui.html",
            "/v3/api-docs/**",
            "/api-docs/**",

            // Actuator
            "/actuator/**",

            // Error page (avoids 403 masking real error pages)
            "/error"
    };

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
                .csrf(AbstractHttpConfigurer::disable)

                .sessionManagement(session ->
                        session.sessionCreationPolicy(
                                SessionCreationPolicy.STATELESS))

                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(WHITE_LIST)
                        .permitAll()

                        // Events
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/events/**"
                        ).hasAnyRole("ADMIN", "VOLUNTEER")

                        .requestMatchers(
                                "/api/events/**"
                        ).hasRole("ADMIN")

                        // Volunteers
                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/volunteers"
                        ).hasAnyRole("ADMIN", "VOLUNTEER")

                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/volunteers/**"
                        ).hasAnyRole("ADMIN", "VOLUNTEER")

                        .requestMatchers(
                                "/api/volunteers/**"
                        ).hasRole("ADMIN")

                        // Applications
                        .requestMatchers(
                                "/api/applications/**"
                        ).hasAnyRole("ADMIN", "VOLUNTEER")

                        // Attendance
                        .requestMatchers(
                                "/api/attendance/**"
                        ).hasRole("ADMIN")

                        // Reports
                        .requestMatchers(
                                "/api/reports/**"
                        ).hasRole("ADMIN")

                        // Dashboard
                        .requestMatchers(
                                "/api/dashboard/**"
                        ).hasRole("ADMIN")

                        .anyRequest()
                        .authenticated()
                )

                .authenticationProvider(authenticationProvider())

                .addFilterBefore(
                        jwtAuthFilter,
                        UsernamePasswordAuthenticationFilter.class
                );

        return http.build();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {

        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider();

        provider.setUserDetailsService(
                userDetailsService
        );

        provider.setPasswordEncoder(
                passwordEncoder()
        );

        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration)
            throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring()
                .requestMatchers(
                        "/",
                        "/index.html",
                        "/login.html",
                        "/register.html",
                        "/dashboard.html",
                        "/admin-dashboard.html",
                        "/volunteer-dashboard.html",  // ✅ add this
                        "/css/**",
                        "/js/**",
                        "/images/**",
                        "/fonts/**",
                        "/favicon.ico",
                        "/error"
                );
    }

}