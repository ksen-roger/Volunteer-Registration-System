package com.volunteer.management.controller;

import com.volunteer.management.dto.request.ApplicationStatusRequest;
import com.volunteer.management.dto.response.ApiResponse;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerEventResponse;
import com.volunteer.management.enums.ApplicationStatus;
import com.volunteer.management.service.VolunteerEventService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Volunteer Event Applications", description = "Apply, approve, reject, and track event applications")
public class VolunteerEventController {

    private final VolunteerEventService volunteerEventService;

    @PostMapping("/apply")
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Apply for an event")
    public ResponseEntity<ApiResponse<VolunteerEventResponse>> apply(
            @RequestParam Long volunteerId,
            @RequestParam Long eventId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Application submitted successfully",
                        volunteerEventService.applyForEvent(volunteerId, eventId)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Approve or reject an application")
    public ResponseEntity<ApiResponse<VolunteerEventResponse>> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody ApplicationStatusRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(ApiResponse.success("Application status updated",
                volunteerEventService.updateStatus(id, request, userDetails.getUsername())));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Get application by ID")
    public ResponseEntity<ApiResponse<VolunteerEventResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Application retrieved",
                volunteerEventService.getById(id)));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "List applications with filters and pagination")
    public ResponseEntity<ApiResponse<PagedResponse<VolunteerEventResponse>>> getApplications(
            @RequestParam(required = false) Long volunteerId,
            @RequestParam(required = false) Long eventId,
            @RequestParam(required = false) ApplicationStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        return ResponseEntity.ok(ApiResponse.success("Applications retrieved",
                volunteerEventService.getApplications(volunteerId, eventId, status,
                        page, size, sortBy, sortDir)));
    }

    @DeleteMapping("/{id}/withdraw")
    @PreAuthorize("hasAnyRole('ADMIN','VOLUNTEER')")
    @Operation(summary = "Withdraw a pending application")
    public ResponseEntity<ApiResponse<Void>> withdraw(
            @PathVariable Long id,
            @RequestParam Long volunteerId) {
        volunteerEventService.withdraw(id, volunteerId);
        return ResponseEntity.ok(ApiResponse.<Void>success("Application withdrawn successfully"));
    }
}
