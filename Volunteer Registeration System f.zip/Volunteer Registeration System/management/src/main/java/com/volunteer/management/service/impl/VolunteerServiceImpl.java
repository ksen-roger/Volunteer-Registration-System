package com.volunteer.management.service.impl;


import com.volunteer.management.dto.request.VolunteerRequest;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.dto.response.VolunteerResponse;
import com.volunteer.management.model.Volunteer;
import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;
import com.volunteer.management.exception.DuplicateResourceException;
import com.volunteer.management.exception.ResourceNotFoundException;
import com.volunteer.management.mapper.VolunteerMapper;
import com.volunteer.management.repository.UserRepository;
import com.volunteer.management.repository.VolunteerRepository;
import com.volunteer.management.service.VolunteerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class VolunteerServiceImpl implements VolunteerService {

    private final VolunteerRepository volunteerRepository;
    private final UserRepository userRepository;
    private final VolunteerMapper volunteerMapper;

    @Override
    @Transactional
    public VolunteerResponse createVolunteer(VolunteerRequest request, String userEmail) {
        if (volunteerRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException(
                    "Volunteer already exists with email: " + request.getEmail());
        }

        Volunteer volunteer = volunteerMapper.toEntity(request);

        if (userEmail != null) {
            userRepository.findByEmail(userEmail).ifPresent(volunteer::setUser);
        }

        Volunteer saved = volunteerRepository.save(volunteer);
        log.info("Volunteer created: {}", saved.getVolunteerId());
        return volunteerMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public VolunteerResponse updateVolunteer(Long id, VolunteerRequest request) {
        Volunteer volunteer = findById(id);

        if (!volunteer.getEmail().equals(request.getEmail())
                && volunteerRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException(
                    "Email already in use: " + request.getEmail());
        }

        volunteerMapper.update(request, volunteer);
        Volunteer updated = volunteerRepository.save(volunteer);
        log.info("Volunteer updated: {}", id);
        return volunteerMapper.toResponse(updated);
    }

    @Override
    @Transactional
    public void deleteVolunteer(Long id) {
        volunteerRepository.delete(findById(id));
        log.info("Volunteer deleted: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public VolunteerResponse getVolunteerById(Long id) {
        return volunteerMapper.toResponse(findById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public VolunteerResponse getVolunteerByEmail(String email) {
        Volunteer volunteer = volunteerRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Volunteer", "email", email));
        return volunteerMapper.toResponse(volunteer);
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<VolunteerResponse> getAllVolunteers(
            int page, int size, String sortBy, String sortDir) {
        Page<Volunteer> result =
                volunteerRepository.findAll(pageable(page, size, sortBy, sortDir));
        return toPagedResponse(result);
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<VolunteerResponse> searchVolunteers(
            String search, Gender gender, Availability availability,
            int page, int size, String sortBy, String sortDir) {
        Page<Volunteer> result = volunteerRepository.searchVolunteers(
                search, gender, availability, pageable(page, size, sortBy, sortDir));
        return toPagedResponse(result);
    }

    @Override
    @Transactional(readOnly = true)
    public List<VolunteerResponse> getAllForReport() {
        return volunteerRepository.findAll()
                .stream()
                .map(volunteerMapper::toResponse)
                .toList();
    }

    // ── Private helpers ──────────────────────────────────────────────
    private Volunteer findById(Long id) {
        return volunteerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Volunteer", "id", id));
    }

    private Pageable pageable(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        return PageRequest.of(page, size, sort);
    }

    private PagedResponse<VolunteerResponse> toPagedResponse(Page<Volunteer> p) {
        return PagedResponse.<VolunteerResponse>builder()
                .content(p.getContent().stream().map(volunteerMapper::toResponse).toList())
                .pageNumber(p.getNumber())
                .pageSize(p.getSize())
                .totalElements(p.getTotalElements())
                .totalPages(p.getTotalPages())
                .last(p.isLast())
                .first(p.isFirst())
                .build();
    }
}
