package com.volunteer.management.service;


import com.volunteer.management.dto.response.DashboardResponse;

public interface DashboardService {
    DashboardResponse getStats();
}
