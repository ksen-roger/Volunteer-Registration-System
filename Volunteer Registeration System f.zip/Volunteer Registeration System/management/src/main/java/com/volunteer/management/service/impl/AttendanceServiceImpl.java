package com.volunteer.management.service.impl;

import com.volunteer.management.dto.request.AttendanceRequest;
import com.volunteer.management.dto.response.AttendanceResponse;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.model.Attendance;
import com.volunteer.management.model.Event;
import com.volunteer.management.model.Volunteer;
import com.volunteer.management.exception.BadRequestException;
import com.volunteer.management.exception.DuplicateResourceException;
import com.volunteer.management.exception.ResourceNotFoundException;
import com.volunteer.management.mapper.AttendanceMapper;
import com.volunteer.management.repository.AttendanceRepository;
import com.volunteer.management.repository.EventRepository;
import com.volunteer.management.repository.VolunteerEventRepository;
import com.volunteer.management.repository.VolunteerRepository;
import com.volunteer.management.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final VolunteerRepository volunteerRepository;
    private final EventRepository eventRepository;
    private final VolunteerEventRepository volunteerEventRepository;
    private final AttendanceMapper attendanceMapper;

    @Override
    @Transactional
    public AttendanceResponse markAttendance(AttendanceRequest request) {
        Volunteer volunteer = volunteerRepository.findById(request.getVolunteerId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Volunteer", "id", request.getVolunteerId()));

        Event event = eventRepository.findById(request.getEventId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Event", "id", request.getEventId()));

        if (!volunteerEventRepository.existsByVolunteerVolunteerIdAndEventEventId(
                request.getVolunteerId(), request.getEventId())) {
            throw new BadRequestException("Volunteer is not registered for this event");
        }

        if (attendanceRepository.existsByVolunteerVolunteerIdAndEventEventIdAndAttendanceDate(
                request.getVolunteerId(), request.getEventId(), request.getAttendanceDate())) {
            throw new DuplicateResourceException(
                    "Attendance already marked for this date");
        }

        Attendance attendance = Attendance.builder()
                .volunteer(volunteer)
                .event(event)
                .present(request.getPresent())
                .attendanceDate(request.getAttendanceDate())
                .notes(request.getNotes())
                .build();

        Attendance saved = attendanceRepository.save(attendance);
        log.info("Attendance marked: volunteer={} event={}",
                request.getVolunteerId(), request.getEventId());
        return attendanceMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public AttendanceResponse updateAttendance(Long id, AttendanceRequest request) {
        Attendance attendance = findById(id);
        attendance.setPresent(request.getPresent());
        attendance.setNotes(request.getNotes());
        attendance.setAttendanceDate(request.getAttendanceDate());
        Attendance updated = attendanceRepository.save(attendance);
        log.info("Attendance updated: {}", id);
        return attendanceMapper.toResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public AttendanceResponse getAttendanceById(Long id) {
        return attendanceMapper.toResponse(findById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<AttendanceResponse> getAttendances(
            Long volunteerId, Long eventId, LocalDate fromDate, LocalDate toDate,
            Boolean present, int page, int size, String sortBy, String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<Attendance> result = attendanceRepository.searchAttendance(
                volunteerId, eventId, fromDate, toDate, present, pageable);

        return PagedResponse.<AttendanceResponse>builder()
                .content(result.getContent().stream()
                        .map(attendanceMapper::toResponse).toList())
                .pageNumber(result.getNumber())
                .pageSize(result.getSize())
                .totalElements(result.getTotalElements())
                .totalPages(result.getTotalPages())
                .last(result.isLast())
                .first(result.isFirst())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AttendanceResponse> getAllForReport() {
        return attendanceRepository.findAll()
                .stream()
                .map(attendanceMapper::toResponse)
                .toList();
    }

    private Attendance findById(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Attendance", "id", id));
    }
}
