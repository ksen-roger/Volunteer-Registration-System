package com.volunteer.management.dto.response;


import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EventResponse {

    private Long eventId;
    private String eventName;
    private String description;
    private String location;
    private LocalDate eventDate;
    private Integer requiredVolunteers;
    private long approvedVolunteersCount;
    private String organizer;
    private boolean active;
    private LocalDateTime createdAt;
}