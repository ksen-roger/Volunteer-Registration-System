package com.volunteer.management.dto.response;

import com.volunteer.management.enums.ApplicationStatus;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VolunteerEventResponse {

    private Long id;
    private Long volunteerId;
    private String volunteerName;
    private String volunteerEmail;
    private Long eventId;
    private String eventName;
    private String eventLocation;
    private ApplicationStatus status;
    private LocalDateTime appliedDate;
    private LocalDateTime reviewedDate;
    private String reviewedBy;
    private String remarks;
}
