package com.volunteer.management.config;


import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title       = "Volunteer Registration & Management System API",
                version     = "1.0.0",
                description = "A full-featured REST API for managing volunteers, "
                        + "events, registrations, attendance and reports "
                        + "with JWT based security and role based access control.",
                contact     = @Contact(
                        name  = "Admin",
                        email = "admin@volunteer.com"
                ),
                license     = @License(
                        name = "Apache 2.0",
                        url  = "https://www.apache.org/licenses/LICENSE-2.0"
                )
        ),
        servers = {
                @Server(
                        url         = "http://localhost:8080",
                        description = "Local Development Server"
                ),
                @Server(
                        url         = "https://api.volunteer.com",
                        description = "Production Server"
                )
        },
        security = @SecurityRequirement(name = "bearerAuth")
)
@SecurityScheme(
        name         = "bearerAuth",
        description  = "Enter JWT token with Bearer prefix: Bearer <your-token>",
        scheme       = "bearer",
        type         = SecuritySchemeType.HTTP,
        bearerFormat = "JWT",
        in           = SecuritySchemeIn.HEADER
)
public class OpenApiConfig {
}
