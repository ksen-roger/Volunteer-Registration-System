package com.volunteer.management.service;



import com.volunteer.management.dto.request.EventRequest;
import com.volunteer.management.dto.response.EventResponse;
import com.volunteer.management.dto.response.PagedResponse;

import java.time.LocalDate;
import java.util.List;

public interface EventService {

    EventResponse createEvent(EventRequest request);

    EventResponse updateEvent(Long id, EventRequest request);

    void deleteEvent(Long id);

    EventResponse getEventById(Long id);

    PagedResponse<EventResponse> getAllEvents(
            int page, int size, String sortBy, String sortDir);

    PagedResponse<EventResponse> searchEvents(
            String search, LocalDate fromDate, LocalDate toDate, Boolean active,
            int page, int size, String sortBy, String sortDir);

    List<EventResponse> getAllForReport();
}
