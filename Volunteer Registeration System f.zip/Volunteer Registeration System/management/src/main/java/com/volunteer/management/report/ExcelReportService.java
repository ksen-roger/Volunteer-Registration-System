package com.volunteer.management.report;


import com.volunteer.management.dto.response.AttendanceResponse;
import com.volunteer.management.dto.response.EventResponse;
import com.volunteer.management.dto.response.VolunteerResponse;
import com.volunteer.management.service.AttendanceService;
import com.volunteer.management.service.EventService;
import com.volunteer.management.service.VolunteerService;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ExcelReportService {

    private final VolunteerService volunteerService;
    private final EventService eventService;
    private final AttendanceService attendanceService;

    // ───────────────────────────────────────────────────────────────
    // 1. Volunteer Report
    // ───────────────────────────────────────────────────────────────
    public byte[] generateVolunteerReport() throws IOException {
        List<VolunteerResponse> volunteers = volunteerService.getAllForReport();

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Volunteers");

            CellStyle titleStyle   = createTitleStyle(workbook);
            CellStyle headerStyle  = createHeaderStyle(workbook);
            CellStyle dataStyle    = createDataStyle(workbook);
            CellStyle altDataStyle = createAltDataStyle(workbook);

            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Volunteer Registration Report");
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));

            String[] headers = {
                    "ID", "First Name", "Last Name", "Email", "Phone",
                    "Age", "Gender", "Skills", "Availability", "Registration Date"
            };
            Row headerRow = sheet.createRow(2);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowNum = 3;
            for (VolunteerResponse v : volunteers) {
                Row row = sheet.createRow(rowNum++);
                CellStyle style = (rowNum % 2 == 0) ? altDataStyle : dataStyle;
                createCell(row, 0, String.valueOf(v.getVolunteerId()), style);
                createCell(row, 1, v.getFirstName(), style);
                createCell(row, 2, v.getLastName(), style);
                createCell(row, 3, v.getEmail(), style);
                createCell(row, 4, v.getPhone(), style);
                createCell(row, 5, String.valueOf(v.getAge()), style);
                createCell(row, 6, v.getGender() != null ? v.getGender().name() : "", style);
                createCell(row, 7, v.getSkills() != null ? v.getSkills() : "", style);
                createCell(row, 8, v.getAvailability() != null ? v.getAvailability().name() : "", style);
                createCell(row, 9, v.getRegistrationDate() != null ? v.getRegistrationDate().toString() : "", style);
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            return toByteArray(workbook);
        }
    }

    // ───────────────────────────────────────────────────────────────
    // 2. Event Report
    // ───────────────────────────────────────────────────────────────
    public byte[] generateEventReport() throws IOException {
        List<EventResponse> events = eventService.getAllForReport();

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Events");

            CellStyle titleStyle   = createTitleStyle(workbook);
            CellStyle headerStyle  = createHeaderStyle(workbook);
            CellStyle dataStyle    = createDataStyle(workbook);
            CellStyle altDataStyle = createAltDataStyle(workbook);

            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Event Management Report");
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 7));

            String[] headers = {
                    "ID", "Event Name", "Location", "Event Date",
                    "Required Volunteers", "Approved Volunteers", "Organizer", "Status"
            };
            Row headerRow = sheet.createRow(2);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowNum = 3;
            for (EventResponse e : events) {
                Row row = sheet.createRow(rowNum++);
                CellStyle style = (rowNum % 2 == 0) ? altDataStyle : dataStyle;
                createCell(row, 0, String.valueOf(e.getEventId()), style);
                createCell(row, 1, e.getEventName(), style);
                createCell(row, 2, e.getLocation(), style);
                createCell(row, 3, e.getEventDate() != null ? e.getEventDate().toString() : "", style);
                createCell(row, 4, String.valueOf(e.getRequiredVolunteers()), style);
                createCell(row, 5, String.valueOf(e.getApprovedVolunteersCount()), style);
                createCell(row, 6, e.getOrganizer(), style);
                createCell(row, 7, e.isActive() ? "ACTIVE" : "INACTIVE", style);
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            return toByteArray(workbook);
        }
    }

    // ───────────────────────────────────────────────────────────────
    // 3. Attendance Report
    // ───────────────────────────────────────────────────────────────
    public byte[] generateAttendanceReport() throws IOException {
        List<AttendanceResponse> attendances = attendanceService.getAllForReport();

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Attendance");

            CellStyle titleStyle   = createTitleStyle(workbook);
            CellStyle headerStyle  = createHeaderStyle(workbook);
            CellStyle dataStyle    = createDataStyle(workbook);
            CellStyle altDataStyle = createAltDataStyle(workbook);

            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Attendance Report");
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 6));

            String[] headers = {
                    "ID", "Volunteer Name", "Email", "Event Name",
                    "Attendance Date", "Present", "Notes"
            };
            Row headerRow = sheet.createRow(2);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowNum = 3;
            for (AttendanceResponse a : attendances) {
                Row row = sheet.createRow(rowNum++);
                CellStyle style = (rowNum % 2 == 0) ? altDataStyle : dataStyle;
                createCell(row, 0, String.valueOf(a.getAttendanceId()), style);
                createCell(row, 1, a.getVolunteerName(), style);
                createCell(row, 2, a.getVolunteerEmail(), style);
                createCell(row, 3, a.getEventName(), style);
                createCell(row, 4, a.getAttendanceDate() != null ? a.getAttendanceDate().toString() : "", style);
                createCell(row, 5, a.isPresent() ? "YES" : "NO", style);
                createCell(row, 6, a.getNotes() != null ? a.getNotes() : "", style);
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            return toByteArray(workbook);
        }
    }

    // ───────────────────────────────────────────────────────────────
    // Helper Methods
    // ───────────────────────────────────────────────────────────────
    private void createCell(Row row, int col, String value, CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 16);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.SEA_GREEN.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }

    private CellStyle createAltDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }

    private byte[] toByteArray(Workbook workbook) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            workbook.write(out);
            return out.toByteArray();
        }
    }
}