package com.volunteer.management.repository;

import com.volunteer.management.model.Volunteer;
import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {

    Optional<Volunteer> findByEmail(String email);

    boolean existsByEmail(String email);

    Optional<Volunteer> findByUserEmail(String email);

    @Query("""
        SELECT v FROM Volunteer v
        WHERE (:search IS NULL
               OR LOWER(v.firstName) LIKE LOWER(CONCAT('%',:search,'%'))
               OR LOWER(v.lastName)  LIKE LOWER(CONCAT('%',:search,'%'))
               OR LOWER(v.email)     LIKE LOWER(CONCAT('%',:search,'%'))
               OR LOWER(v.skills)    LIKE LOWER(CONCAT('%',:search,'%')))
          AND (:gender       IS NULL OR v.gender       = :gender)
          AND (:availability IS NULL OR v.availability = :availability)
        """)
    Page<Volunteer> searchVolunteers(
            @Param("search")       String search,
            @Param("gender")       Gender gender,
            @Param("availability") Availability availability,
            Pageable pageable);
}
