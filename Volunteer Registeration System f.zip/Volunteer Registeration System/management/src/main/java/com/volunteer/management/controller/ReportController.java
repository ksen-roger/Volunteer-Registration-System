package com.volunteer.management.controller;

import com.volunteer.management.report.ExcelReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Reports", description = "Generate downloadable Excel reports")
public class ReportController {

    private final ExcelReportService excelReportService;

    @GetMapping("/volunteers")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Generate volunteer Excel report")
    public ResponseEntity<byte[]> volunteerReport() throws IOException {
        byte[] report = excelReportService.generateVolunteerReport();
        return buildExcelResponse(report, "volunteer_report_" + LocalDate.now() + ".xlsx");
    }

    @GetMapping("/events")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Generate event Excel report")
    public ResponseEntity<byte[]> eventReport() throws IOException {
        byte[] report = excelReportService.generateEventReport();
        return buildExcelResponse(report, "event_report_" + LocalDate.now() + ".xlsx");
    }

    @GetMapping("/attendance")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Generate attendance Excel report")
    public ResponseEntity<byte[]> attendanceReport() throws IOException {
        byte[] report = excelReportService.generateAttendanceReport();
        return buildExcelResponse(report, "attendance_report_" + LocalDate.now() + ".xlsx");
    }

    private ResponseEntity<byte[]> buildExcelResponse(byte[] report, String filename) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDispositionFormData("attachment", filename);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        return ResponseEntity.ok().headers(headers).body(report);
    }
}