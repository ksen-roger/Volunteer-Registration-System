package com.volunteer.management.service.impl;

import com.volunteer.management.dto.request.EventRequest;
import com.volunteer.management.dto.response.EventResponse;
import com.volunteer.management.dto.response.PagedResponse;
import com.volunteer.management.model.Event;
import com.volunteer.management.exception.ResourceNotFoundException;
import com.volunteer.management.mapper.EventMapper;
import com.volunteer.management.repository.EventRepository;
import com.volunteer.management.service.EventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepository;
    private final EventMapper eventMapper;

    @Override
    @Transactional
    public EventResponse createEvent(EventRequest request) {
        Event saved = eventRepository.save(eventMapper.toEntity(request));
        log.info("Event created: {}", saved.getEventId());
        return eventMapper.toResponse(saved);
    }

    @Override
    @Transactional
    public EventResponse updateEvent(Long id, EventRequest request) {
        Event event = findById(id);
        eventMapper.update(request, event);
        Event updated = eventRepository.save(event);
        log.info("Event updated: {}", id);
        return eventMapper.toResponse(updated);
    }

    @Override
    @Transactional
    public void deleteEvent(Long id) {
        Event event = findById(id);
        event.setActive(false);
        eventRepository.save(event);
        log.info("Event deactivated: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public EventResponse getEventById(Long id) {
        return eventMapper.toResponse(findById(id));
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<EventResponse> getAllEvents(
            int page, int size, String sortBy, String sortDir) {
        Page<Event> result = eventRepository.findAll(pageable(page, size, sortBy, sortDir));
        return toPagedResponse(result);
    }

    @Override
    @Transactional(readOnly = true)
    public PagedResponse<EventResponse> searchEvents(
            String search, LocalDate fromDate, LocalDate toDate, Boolean active,
            int page, int size, String sortBy, String sortDir) {
        Page<Event> result = eventRepository.searchEvents(
                search, fromDate, toDate, active, pageable(page, size, sortBy, sortDir));
        return toPagedResponse(result);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventResponse> getAllForReport() {
        return eventRepository.findAll()
                .stream()
                .map(eventMapper::toResponse)
                .toList();
    }

    // ── Private helpers ──────────────────────────────────────────────
    private Event findById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", id));
    }

    private Pageable pageable(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        return PageRequest.of(page, size, sort);
    }

    private PagedResponse<EventResponse> toPagedResponse(Page<Event> p) {
        return PagedResponse.<EventResponse>builder()
                .content(p.getContent().stream().map(eventMapper::toResponse).toList())
                .pageNumber(p.getNumber())
                .pageSize(p.getSize())
                .totalElements(p.getTotalElements())
                .totalPages(p.getTotalPages())
                .last(p.isLast())
                .first(p.isFirst())
                .build();
    }
}
