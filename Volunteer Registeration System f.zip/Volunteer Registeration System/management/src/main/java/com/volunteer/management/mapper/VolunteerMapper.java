package com.volunteer.management.mapper;

import com.volunteer.management.dto.request.VolunteerRequest;
import com.volunteer.management.dto.response.VolunteerResponse;
import com.volunteer.management.model.Volunteer;
import org.springframework.stereotype.Component;

@Component
public class VolunteerMapper {

    public Volunteer toEntity(VolunteerRequest req) {
        return Volunteer.builder()
                .firstName(req.getFirstName())
                .lastName(req.getLastName())
                .email(req.getEmail())
                .phone(req.getPhone())
                .age(req.getAge())
                .gender(req.getGender())
                .address(req.getAddress())
                .skills(req.getSkills())
                .availability(req.getAvailability())
                .emergencyContact(req.getEmergencyContact())
                .build();
    }

    public VolunteerResponse toResponse(Volunteer v) {
        return VolunteerResponse.builder()
                .volunteerId(v.getVolunteerId())
                .firstName(v.getFirstName())
                .lastName(v.getLastName())
                .fullName(v.getFirstName() + " " + v.getLastName())
                .email(v.getEmail())
                .phone(v.getPhone())
                .age(v.getAge())
                .gender(v.getGender())
                .address(v.getAddress())
                .skills(v.getSkills())
                .availability(v.getAvailability())
                .emergencyContact(v.getEmergencyContact())
                .registrationDate(v.getRegistrationDate())
                .userId(v.getUser() != null ? v.getUser().getId() : null)
                .build();
    }

    public void update(VolunteerRequest req, Volunteer v) {
        v.setFirstName(req.getFirstName());
        v.setLastName(req.getLastName());
        v.setPhone(req.getPhone());
        v.setAge(req.getAge());
        v.setGender(req.getGender());
        v.setAddress(req.getAddress());
        v.setSkills(req.getSkills());
        v.setAvailability(req.getAvailability());
        v.setEmergencyContact(req.getEmergencyContact());
    }
}