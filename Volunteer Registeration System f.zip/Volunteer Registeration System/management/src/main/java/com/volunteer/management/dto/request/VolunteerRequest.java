package com.volunteer.management.dto.request;

import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VolunteerRequest {

    @NotBlank(message = "First name is required")
    @Size(min = 2, max = 50)
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(min = 2, max = 50)
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone is required")
    @Pattern(
            regexp = "^[+]?[0-9]{10,15}$",
            message = "Invalid phone number"
    )
    private String phone;

    @NotNull(message = "Age is required")
    @Min(value = 16, message = "Minimum age is 16")
    @Max(value = 100, message = "Maximum age is 100")
    private Integer age;

    @NotNull(message = "Gender is required")
    private Gender gender;

    @NotBlank(message = "Address is required")
    @Size(max = 255)
    private String address;

    @Size(max = 500, message = "Skills cannot exceed 500 characters")
    private String skills;

    @NotNull(message = "Availability is required")
    private Availability availability;

    @NotBlank(message = "Emergency contact is required")
    @Pattern(
            regexp = "^[+]?[0-9]{10,15}$",
            message = "Invalid emergency contact number"
    )
    private String emergencyContact;
}