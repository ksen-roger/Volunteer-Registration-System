package com.volunteer.management.dto.response;

import com.volunteer.management.enums.Availability;
import com.volunteer.management.enums.Gender;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VolunteerResponse {

    private Long volunteerId;
    private String firstName;
    private String lastName;
    private String fullName;
    private String email;
    private String phone;
    private Integer age;
    private Gender gender;
    private String address;
    private String skills;
    private Availability availability;
    private String emergencyContact;
    private LocalDateTime registrationDate;
    private Long userId;
}