package com.volunteer.management.enums;

public enum Role {
    ADMIN,
    VOLUNTEER
}
